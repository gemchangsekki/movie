import React from 'react';
import AntCard from '../commons/AntCard';
import { Row } from 'antd';
import { IMAGE_BASE_URL } from '../Config';

function ImageList() {
  return (
    <Row gutter={[10, 10]}>
      {props.map(targets => {
        if (targets.profile_path != null)
          return (
            <React.Fragment key={actor.id}>
              <AntCard
                Detail
                path={`${IMAGE_BASE_URL}w400${actor.profile_path}`}
                name={targets.name}
              />
            </React.Fragment>
          );
      })}
    </Row>
  )
}

export default ImageList